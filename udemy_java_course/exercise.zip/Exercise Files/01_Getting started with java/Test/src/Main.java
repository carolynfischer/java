
class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello World!");
		
		String test = "Hello";
		
		switch(test){
		case "Hello" :
			System.out.println("Yo");
			break;
		default : 
			System.out.println("bool");
		
		}

	}

}
