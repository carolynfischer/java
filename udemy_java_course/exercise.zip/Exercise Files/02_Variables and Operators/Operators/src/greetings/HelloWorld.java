package greetings;

public class HelloWorld {
	
	public static void main(String[] args)
	{
		System.out.println("Hello World!");
		
		//int number = 3;
		//number = 3 + 2;
		//number = 5 - 1;
		//number++;
		//number--;
		//number += 2;
		//number = number + 2;
		
		//System.out.println(number);
		
		//boolean value = true;
		//System.out.println(value);*/
		
		//System.out.println(3>2);
		//System.out.println(3>=3);
		//System.out.println(3<=3);
		//System.out.println(3==3);
		//System.out.println(3!=3);
		
		//System.out.println(true && true);
		//System.out.println(true && false);
		//System.out.println(true || false);
		//System.out.println(false || false);
		
		//System.out.println(!false);
		//System.out.println(!true);
		System.out.println(!!true);
		
	}  

}
