package com.example.greetings;

public class HelloWorld {

	public static void main(String[] args)
	{
		
		String[] names = {"John", "Sara", "Mike"};
		
		System.out.println(names[1]);
		/*System.out.println(names[4]);*/
		
		
		/*String[] names = new String[4];
		names[0] = "John";
		names[1] = "Sara";
		names[2] = "Mike";
		
		System.out.println(names[1]);
		System.out.println(names[3]);*/
	}  

}
