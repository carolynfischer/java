package com.example.greetings;

public class HelloWorld {
	
	public static void main(String[] args)
	{
		final String COUNTRY = "US";
		/*COUNTRY = "CA";*/
		
		System.out.println("Hello World!");
		
		/*int score = "Hello Smith";*/
		/*int score = 6 + 4;*/
		int score = 6, age, numbers;
		age = 32;
		System.out.println(score);
		
		/*String firstName = "Sara";*/
		String firstName ;
		firstName = "Sara";
		firstName = "John"
		
		/*boolean firstName = true*/
		System.out.println(firstName);
	}

}
