package greetings;

public class HelloWorld {
	
	private static int age = 50;
	
	public static void main(String[] args)
	{
		System.out.println("Hello World!");
		
		{
			int age = 25;
			System.out.println(age);
		}
		    int age = 20;
		
		
	}  

}
