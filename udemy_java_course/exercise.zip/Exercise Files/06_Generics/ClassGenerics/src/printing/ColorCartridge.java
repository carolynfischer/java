package printing;

public class ColorCartridge {
	
	@Override
	public String toString()
	{
		return "Color!";
    }

}
