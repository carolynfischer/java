package printing;

public class BWCartridge {

	@Override
	public String toString()
	{
		return "BW!";
    }
}
