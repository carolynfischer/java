package printing;

public interface ICartridge
{
	public String getFillPercentage();
}
