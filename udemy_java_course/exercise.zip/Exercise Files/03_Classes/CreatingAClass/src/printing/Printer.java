package printing;

public class Printer {
	
	public boolean isOn;
	public String modelNumber;

}
