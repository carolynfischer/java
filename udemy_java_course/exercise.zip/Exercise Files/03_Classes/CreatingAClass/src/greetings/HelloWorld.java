package greetings;

public class HelloWorld {
	
	public static void main(String[] args)
	{
	
	}  

}
