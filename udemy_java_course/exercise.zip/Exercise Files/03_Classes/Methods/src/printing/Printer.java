package printing;

public class Printer {
	
	public boolean isOn;
	public String modelNumber;

	public void print()
	{
		System.out.println(modelNumber);
	}
}
