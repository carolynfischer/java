package greetings;

import printing.Printer;

public class HelloWorld {
	
	public static void main(String[] args)
	{
		//Printer myPrinter = new Printer(false,"MY PRINTER");
		
		Printer myPrinter = new Printer(true,"MY PRINTER");
		
		//myPrinter.print(0);
		
		myPrinter.print(1);
		
		//myPrinter.print(2);
		
		//myPrinter.print(50);
		
		//myPrinter.print(5);
		
		
	}  

}
